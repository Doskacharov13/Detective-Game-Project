extends Panel

@onready var item: TextureRect = $Item

func pickFromSlot():
	item.texture = null


func putIntoSlot(new_texture):
	item.texture = new_texture
